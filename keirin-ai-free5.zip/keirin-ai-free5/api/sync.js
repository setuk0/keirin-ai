const today=require('./today');

module.exports=async function handler(req,res){
  // Vercel Cron sends GET requests. This endpoint intentionally refreshes the same
  // upstream source even when nobody has the website open.
  const originalStatus=res.status.bind(res);
  let payload;
  const proxy={
    setHeader:(...args)=>res.setHeader(...args),
    status:(code)=>({json:(body)=>{payload={code,body};return body;}})
  };
  await today(req,proxy);
  const ok=payload && payload.code===200;
  originalStatus(ok?200:502).json({ok,ranAt:new Date().toISOString(),upstream:payload?.body||null});
};
