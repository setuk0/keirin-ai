# 競輪AI 無料5分更新版

Vercel Hobbyで動かし、GitHub Actionsから5分ごとに当日開催情報APIを呼び出して更新を促す構成です。GitHub Actionsのスケジュール最短間隔は5分です。

## 構成
- Vercel Hobby: Webサイト/API
- GitHub Actions: 5分ごとの自動リフレッシュ
- ブラウザ: サイト表示中は1分ごとに当日開催情報を再取得
- Vercel Cron: 使用しない（Hobbyの1日1回制限を回避）

## GitHubへの公開
1. このフォルダをGitHubリポジトリへアップロード
2. `.github/workflows/refresh-keirin.yml` がmainブランチに入っていることを確認
3. GitHubのActionsタブで `Refresh Keirin data` を有効化
4. `Run workflow` で手動テスト可能

## 注意
GitHub Actionsのscheduled workflowはGitHub側の混雑等で実行時刻が多少ずれることがあります。
